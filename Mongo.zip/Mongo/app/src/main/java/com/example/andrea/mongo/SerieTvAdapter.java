package com.example.andrea.mongo;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class SerieTvAdapter extends RecyclerView.Adapter<SerieTvAdapter.ViewHolder> {

    private static ArrayList<TvSeries> tvSeries;
    private Context context;

    public SerieTvAdapter(Context context, ArrayList<TvSeries> tvSeries) {
        this.context = context;
        this.tvSeries = tvSeries;
    }

    @Override
    public SerieTvAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View viewHolder = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_layout_tvseries, parent, false);
        return new SerieTvAdapter.ViewHolder(viewHolder);
    }

    @Override
    public void onBindViewHolder(SerieTvAdapter.ViewHolder holder, int position) {
        TvSeries v = tvSeries.get(position);
        holder.setItem(v);
    }

    @Override
    public int getItemCount() {
        return tvSeries.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private Button modifica;
        private Button cancella;
        private TextView nome;
        private TextView creatori;
        private TextView descrizione;
        private String nominativo;
        private TvSeries tvSeries;

        public ViewHolder(View itemView) {
            super(itemView);
            modifica = itemView.findViewById(R.id.button);
            cancella = itemView.findViewById(R.id.button2);
            nome = itemView.findViewById(R.id.nome);
            creatori = itemView.findViewById(R.id.creatori);
            descrizione = itemView.findViewById(R.id.descrizione);

            itemView.setOnClickListener(this);

            modifica.setOnClickListener(view -> {
                FragmentManager manager = ((MainActivity) context).getSupportFragmentManager();
                Bundle bundle = new Bundle();
                bundle.putString("nome", nominativo);
                bundle.putString("id", "" + tvSeries.getId().get$oid());
                bundle.putString("descrizione", tvSeries.getDescrizione());
                bundle.putString("creatori", tvSeries.getCreatori());
                ModificaDialogFragment dialogFragment = new ModificaDialogFragment();
                dialogFragment.setArguments(bundle);
                dialogFragment.show(manager, "Modifica TvSeries");
            });

            cancella.setOnClickListener(view -> {

                String titleText = "Cancella";
                AlertDialog.Builder alert = new AlertDialog.Builder(view.getContext());
                alert.setTitle(titleText);
                alert.setMessage("Sei sicuro di voler rimuovere " + nominativo + "?");
                alert.setPositiveButton("OK", (dialogInterface, i) -> {
                    InterazioneServer interazioneServer = new InterazioneServer();
                    interazioneServer.deleteTvSeries(tvSeries.getId().get$oid());
                });
                alert.setNegativeButton("Cancel", (dialogInterface, i) -> {
                });
                Dialog dialog = alert.create();
                dialog.show();
            });
        }

        public void setItem(TvSeries tvSeries) {
            this.nome.setText(tvSeries.getNome());
            this.creatori.setText(tvSeries.getCreatori());
            nominativo = tvSeries.getNome();
            this.tvSeries = tvSeries;
        }

        @Override
        public void onClick(View view) {
            String text = descrizione.getText().toString();
            if (text.equals("Click to see description")) {
                String app = tvSeries.getDescrizione();
                if (app.equals("")) {
                    descrizione.setText("Nessuna descrizione");
                } else {
                    descrizione.setText(app);
                }
            } else {
                descrizione.setText("Click to see description");
            }
        }
    }
}

