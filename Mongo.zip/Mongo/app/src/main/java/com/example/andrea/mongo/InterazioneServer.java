package com.example.andrea.mongo;

import android.util.Log;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;

public class InterazioneServer {

    private RetrofitService mService;

    public InterazioneServer() {
        Log.d("MainActivity", "create Retrofit Service");
        mService = RetrofitClient.getClient().create(RetrofitService.class);
    }

    public void addTvSeries(TvSeries tvSeries) {
        mService.addTvSeries(tvSeries).enqueue(new Callback<TvSeries>() {
            @Override
            public void onResponse(Call<TvSeries> call, Response<TvSeries> response) {
                if (response.isSuccessful()) {
                    Log.i(TAG, "RESPONSE: " + response.body().toString());
                } else {
                    Log.i(TAG, "ERROR: " + response.body().toString());
                }
            }

            @Override
            public void onFailure(Call<TvSeries> call, Throwable t) {
                Log.e(TAG, "ERROR: " + t.getMessage());
            }
        });
    }

    public void modificaTvSeries(String id, TvSeries tvSeries) {
        mService.updateTvSeries(id, tvSeries).enqueue(new Callback<TvSeries>() {
            @Override
            public void onResponse(Call<TvSeries> call, Response<TvSeries> response) {
                if (response.isSuccessful()) {
                    Log.i(TAG, "RESPONSE: " + response.body().toString());
                } else {
                    Log.i(TAG, "ERROR: " + response.body().toString());
                }
            }
            @Override
            public void onFailure(Call<TvSeries> call, Throwable t) {
                Log.e(TAG, "ERROR: " + t.getMessage());
            }
        });
    }

    public void deleteTvSeries(String id) {
        mService.deleteTvSeries(id).enqueue(new Callback<TvSeries>() {
            @Override
            public void onResponse(Call<TvSeries> call, Response<TvSeries> response) {
                if (response.isSuccessful()) {
                    Log.d("MainActivity", "posts loaded from API");
                } else {
                    int statusCode = response.code();
                    Log.d("MainActivity", "result code is: " + statusCode);
                }
            }

            @Override
            public void onFailure(Call<TvSeries> call, Throwable t) {
                Log.d("MainActivity", "error loading from API");
            }
        });
    }

}
