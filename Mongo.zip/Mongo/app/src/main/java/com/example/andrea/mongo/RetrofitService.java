package com.example.andrea.mongo;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by andrea on 24/04/2018.
 */

public interface RetrofitService {

    @GET("modolo/prova")
    Call<Embedded> getTvSeries();

    @GET("modolo/prova")
    Call<Embedded> searchTvSeriesByName(@Query(value = "filter", encoded = true) String query);

    @POST("modolo/prova")
    Call<TvSeries> addTvSeries(@Body TvSeries tvSeries);

    @DELETE("modolo/prova/{id}")
    Call<TvSeries> deleteTvSeries(@Path("id") String id);

    @PUT("modolo/prova/{id}")
    Call<TvSeries> updateTvSeries(@Path("id") String id, @Body TvSeries tvSeries);

}
